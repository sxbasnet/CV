
export default function Header(){

    return(
        <>
            <h1 className="heading">Manage Contacts</h1>
        </>
    )
}